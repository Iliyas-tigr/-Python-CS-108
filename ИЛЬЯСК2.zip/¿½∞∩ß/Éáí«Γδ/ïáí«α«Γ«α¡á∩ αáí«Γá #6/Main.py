import sys
import random
from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget


class StylishApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Динамическое изменение стилей")
        self.setGeometry(100, 100, 400, 200)


        self.central_widget = QWidget()
        self.layout = QVBoxLayout(self.central_widget)


        self.label = QLabel("Нажмите кнопку")
        self.label.setStyleSheet("font-size: 18px; color: black;")
        self.layout.addWidget(self.label)


        self.button = QPushButton("Нажми меня")
        self.button.setStyleSheet("background-color: lightblue; font-size: 16px;")
        self.button.clicked.connect(self.button_clicked)
        self.layout.addWidget(self.button)

        self.setCentralWidget(self.central_widget)

        self.styles = [
            {"label": "font-size: 20px; color: red;", "button": "background-color: yellow; font-size: 18px;"},
            {"label": "font-size: 22px; color: green;", "button": "background-color: pink; font-size: 20px;"},
            {"label": "font-size: 24px; color: blue;", "button": "background-color: orange; font-size: 16px;"},
        ]

    def button_clicked(self):
        self.label.setText("Кнопка нажата!")

        self.change_styles()

    def change_styles(self):
        new_style = random.choice(self.styles)
        self.label.setStyleSheet(new_style["label"])
        self.button.setStyleSheet(new_style["button"])


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = StylishApp()
    window.show()
    sys.exit(app.exec())
